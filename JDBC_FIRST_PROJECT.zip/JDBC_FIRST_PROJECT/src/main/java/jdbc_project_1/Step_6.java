package jdbc_project_1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class Step_6 {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		
		Class.forName("org.postgresql.Driver");
		
		Connection con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/jdbc_project","postgres","sql@123");
		
		/*
		 
		Search Employees by Department
		Input: Department name.
		Show all employees belonging to that department.
		Also display a count of total employees in that particular department.

		 */
		
		PreparedStatement ps = con.prepareStatement("select * from employees where dept=?");
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Department Name : ");
		String dept  = sc.next();
		
		ps.setString(1, dept);
		
		ResultSet rs = ps.executeQuery();
		int count=0;
		
		while(rs.next()) {
				System.out.println(rs.getInt("empid")+" "+rs.getString("name")+" "+rs.getInt("sal")+" "+rs.getString("dept"));
				count++;
			}
		System.out.println("Total Employees : "+count);

	}

}
