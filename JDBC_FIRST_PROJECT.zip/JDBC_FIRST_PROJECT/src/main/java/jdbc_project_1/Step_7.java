package jdbc_project_1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class Step_7 {

	public static void main(String[] args) throws ClassNotFoundException,SQLException {
		
		Class.forName("org.postgresql.Driver");
		
		Connection con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/jdbc_project","postgres","sql@123");
		
		/*
		 
		Increase Salary by adding bonus (Bulk Update)
		Input: Department name, bonus amount
		Increase salary of all employees in that department by an bonus (salary = salary + bonus).
		Show how many records were updated.

		 
		 */

		PreparedStatement ps = con.prepareStatement("update employees set sal = sal + ? where dept=?");
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Bonus : ");
		int bonus = sc.nextInt();
		System.out.println("Enter Department Name : ");
		String dept  = sc.next();
		
		ps.setInt(1, bonus);
		ps.setString(2, dept);
		
		int count = ps.executeUpdate();
		if(count > 0) {
		System.out.println(count+" row updated");
		}
		else {
			System.out.println("Employee Not Found");
		}
		
		con.close();
	}

}
