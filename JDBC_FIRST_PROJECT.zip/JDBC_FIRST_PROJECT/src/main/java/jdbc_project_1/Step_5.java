package jdbc_project_1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class Step_5 {

	public static void main(String[] args) throws ClassNotFoundException,SQLException {


		Class.forName("org.postgresql.Driver");
		
		Connection con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/jdbc_project","postgres","sql@123");
		
		/*
		 
		Delete an Employee
		Input: Employee ID
		Delete the record from the database.
		Confirm before deleting (“Are you sure? Y/N”).
		Delete and display success message.
 
		 */
		
		PreparedStatement ps = con.prepareStatement("delete from employees where empid=?");
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Employee ID : ");
		int empid = sc.nextInt();
		
		System.out.println("Are you sure want to delete ? (Y/N) : ");
		char ch = sc.next().charAt(0);
		
		if(ch=='Y' || ch=='y') {
			ps.setInt(1, empid);
			ps.executeUpdate();
			System.out.println("Record Deleted");
		}
		else {
			System.out.println("Employee Not Found");
		}
		con.close();
		
		
	}

}
