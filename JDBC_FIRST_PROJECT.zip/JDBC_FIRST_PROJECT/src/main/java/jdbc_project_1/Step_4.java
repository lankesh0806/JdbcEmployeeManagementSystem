package jdbc_project_1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class Step_4 {

	public static void main(String[] args) throws ClassNotFoundException,SQLException {
		
		Class.forName("org.postgresql.Driver");
		
		Connection con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/jdbc_project","postgres","sql@123");  // bootstrap class - startup process
		
		/*
		 
		Update Employee Details
		Input: salary , department  and name
		Allow user to update salary, department  based on name

		 
		 */
		

		PreparedStatement ps = con.prepareStatement("update employees set sal=?,dept=? where name=?");
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Employee Salary : ");
		int sal = sc.nextInt();
		System.out.println("Enter Departmenet Name : ");
		String dept = sc.next();
		System.out.println("Enter Name : ");
		String name = sc.next();
		
		ps.setInt(1, sal);
		ps.setString(2, dept);
		ps.setString(3, name);
		
		ps.executeUpdate();
		
		con.close();

	}

}
