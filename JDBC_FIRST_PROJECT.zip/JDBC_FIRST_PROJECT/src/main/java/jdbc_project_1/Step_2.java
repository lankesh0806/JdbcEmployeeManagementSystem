package jdbc_project_1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Step_2 {

	public static void main(String[] args) throws ClassNotFoundException,SQLException {
		
		Class.forName("org.postgresql.Driver");
		
		Connection con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/jdbc_project","postgres","sql@123");  // bootstrap class - startup process
		
		/*
		
	    View All Employees
		Display a list of all employees with details
		Include a count of total employees at the end.

		 */

		PreparedStatement ps = con.prepareStatement("select * from employees");
		ResultSet rs = ps.executeQuery();
		int count =0;
		while(rs.next()) {
			System.out.println(rs.getInt("empid")+" "+rs.getString("name")+" "+rs.getInt("sal")+" "+rs.getString("dept"));
			count++;
		}
		System.out.println("Total Employee : "+count);
		con.close();
	}

}
