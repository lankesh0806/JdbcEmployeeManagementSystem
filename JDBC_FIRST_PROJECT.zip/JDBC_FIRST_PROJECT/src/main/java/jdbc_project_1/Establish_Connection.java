package jdbc_project_1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Calendar;

public class Establish_Connection {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		

		 // 1. To load and Register the Driver
		Class.forName("org.postgresql.Driver");
		
		// 2. To Establish Connection 
		Connection con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/jdbc_project","postgres","sql@123");  // bootstrap class - startup process
		System.out.println("Connection Established");
		
		

	}

}
