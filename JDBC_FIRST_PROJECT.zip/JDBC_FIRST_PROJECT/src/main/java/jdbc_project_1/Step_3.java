package jdbc_project_1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class Step_3 {

	public static void main(String[] args) throws ClassNotFoundException,SQLException{
		
		Class.forName("org.postgresql.Driver");
		
		Connection con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/jdbc_project","postgres","sql@123");  // bootstrap class - startup process
		
		/*
		 
		Search Employee by ID
		Input: Employee ID
		Output: Display employee details if found , else print “Employee Not Found”
		 
		 */

		PreparedStatement ps = con.prepareStatement("select * from employees where empid=?");
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Employee Id : ");
		int empid = sc.nextInt();
		
		ps.setInt(1, empid);
		ResultSet rs = ps.executeQuery();
		if(rs.next()) {
			System.out.println("Employee Found");
			System.out.println(rs.getInt("empid")+" "+rs.getString("name")+" "+rs.getInt("sal")+" "+rs.getString("dept"));
		}
		else {
			System.out.println("Employee Not Found");
		}
		
		con.close();
		

	}

}
