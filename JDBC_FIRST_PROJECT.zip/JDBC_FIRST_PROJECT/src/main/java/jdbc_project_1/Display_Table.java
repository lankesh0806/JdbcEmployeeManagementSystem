package jdbc_project_1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Display_Table {

	public static void main(String[] args) throws ClassNotFoundException,SQLException {


		Class.forName("org.postgresql.Driver");
		
		Connection con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/jdbc_project","postgres","sql@123");  // bootstrap class - startup process
		
		PreparedStatement ps = con.prepareStatement("select * from employees");
		ResultSet rs = ps.executeQuery();
		while(rs.next()) {
			System.out.println(rs.getInt("empid")+" "+rs.getString("name")+" "+rs.getInt("sal")+" "+rs.getString("dept"));
		}
		con.close();

	}

}
