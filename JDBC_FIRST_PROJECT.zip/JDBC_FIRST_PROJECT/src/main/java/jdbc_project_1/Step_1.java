package jdbc_project_1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class Step_1 {

	public static void main(String[] args) throws ClassNotFoundException,SQLException {
		
				Class.forName("org.postgresql.Driver");
				
				Connection con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/jdbc_project","postgres","sql@123");  // bootstrap class - startup process
				
				/*
				Add a New Employee
				Input: Emp id , Name, Department, Salary
				Store in the database	
				 */
				
				PreparedStatement ps = con.prepareStatement("insert into employees(empid,name,sal,dept) values(?,?,?,?)");
				Scanner sc = new Scanner(System.in);
				System.out.println("Enter Employee Id : ");
				int empid = sc.nextInt();
				System.out.println("Enter Employee Name : ");
				String name = sc.next();
				System.out.println("Enter Salary : ");
				int sal = sc.nextInt();
				System.out.println("Enter Department Name : ");
				String dept = sc.next();
				
				ps.setInt(1, empid);
				ps.setString(2, name);
				ps.setInt(3, sal);
				ps.setString(4, dept);
				
				ps.executeUpdate();

				
				con.close();

	}

}
